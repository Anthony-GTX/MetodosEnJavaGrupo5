# Ejercicios APE - Java

Solucion de los ejercicios APE sobre metodos, parametros, void vs return y paso por valor.

## Estructura

| Carpeta | Tema |
|---|---|
| ejercicio1 | Tipos de retorno y error de compilacion |
| ejercicio2 | Metodo void (clase Bienvenida) |
| ejercicio3 | Parametros vs argumentos |
| ejercicio4 | Paso por valor |
| ejercicio5 | Metodo con multiples parametros (clase Calculadora) |
| ejercicio6 | Validacion de datos (verificarEdad) |
| ejercicio7 | Clase Producto (calcularValorTotal) |
| ejercicio8 | Instanciacion e invocacion en el main |

## Como ejecutar

Cada carpeta es independiente. Ejemplo con el ejercicio 5:

```
cd ejercicio5
javac -encoding UTF-8 *.java
java Main
```

Requiere JDK 8 o superior.
